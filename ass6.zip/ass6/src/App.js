import React from 'react';
import Fullcontainer from './components/Fullcontainer'
import './App.css'
function App() {
  return (
    <>
    <Fullcontainer/>
    </>
  );
}

export default App;
